import os
import json
import aioredis
import asyncio
import requests
import requests_async

def handler(event, context):
    loop = asyncio.get_event_loop()

    meta_find_url = os.environ["META_FIND_URL"]

    name = event["name"]
    function = event["function"]

    post_json = {
        "name": name
    }
    params = {
        "Content-Type": "application/json"
    }
    shards = requests.post(url=meta_find_url, json=post_json, params=params).json()["body"]

    post_json = {
        "func_name": function
    }
    params = {
        "Content-Type": "application/json"
    }
    function_url = requests.post(url=meta_find_url, json=post_json, params=params).json()["body"]

    data = loop.run_until_complete(query_job(loop, name, shards, function_url))

    message = {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(data)
    }
    return message

async def query_job(loop,name, shards,function_url):
    write_promises = []
    conns = []
    results = []
    final_result = []

    for shard in shards:
        shard_dict = json.loads(shard)
        conn = await aioredis.create_redis(
            (shard_dict["host"], shard_dict["port"]))
        data = await conn.lrange(name,0,-1)

        post_json = {
            "data": data
        }
        params = {
            "Content-Type": "application/json"
        }
        result = requests_async.post(url=function_url, json=post_json, params=params).json()["body"]
        conns.append(conn)
        results.append(result)

    for write_promise in write_promises:
        await write_promise

    for result in results:
        final_result.extend(await result)

    for conn in conns:
        conn.close()

    return final_result