exports.handler = async (event) => {
    // Dependencies
    var metaFindURL = process.env.META_FIND_URL;
    const redis = require("redis");
    const client = redis.createClient({"url" : redisURL});
    const asyncRedis = require("async-redis");
    const http = require("http")
    const asyncClient = asyncRedis.decorate(client)

    // parsing request
    var name = event.name;
    var data = event.data;



    const response = {
        statusCode: 201,
        body: JSON.stringify({ message: arn})
    };
    
    return response;
}