import os
import json
import requests
import aioredis
import asyncio

def handler(event, context):
    loop = asyncio.get_event_loop()

    meta_find_url = os.environ["META_FIND_URL"]

    name = event["name"]
    data = event["data"]

    json ={
        "name": name
    }
    params = {
        "Content-Type" : "application/json"
    }
    shards = requests.post(url=meta_find_url,json=json,params=params,timeout=1).json()

    loop.run_until_complete(write_job(loop, name, shards, data))

    message = {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": "Successfully written to snekboop " + str(shards)
    }
    return message

async def write_job(loop,name, shards,data):
    write_promises = []
    conns = []
    conn_close_promises = []
    for shard in shards:
        conn = await aioredis.create_redis(
            (shard["host"], int(shard["port"])))
        multi = conn.multi_exec()
        for datum in data:
            multi.append(name,json.dumps(datum))
        conns.append(conn)
        write_promises.append(multi.execute())

    for write_promise in write_promises:
        await write_promise

    for conn in conns:
        conn_close_promises.append(conn.wait_closed())

    for conn_close_promise in conn_close_promises:
        await conn_close_promise
