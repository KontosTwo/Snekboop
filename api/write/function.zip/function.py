import os
import redis
import json
import requests

def handler(event, context):
    redis_host = os.environ["REDIS_HOST"]
    redis_port = os.environ["REDIS_PORT"]
    meta_find_url = os.environ["META_FIND_URL"]

    pool = redis.ConnectionPool(host=redis_host, port=redis_port)
    r = redis.Redis(connection_pool=pool)

    name = event["name"]
    data = event["data"]
    data_length = len(data)

    body ={
        "name": name
    }
    shards = requests.get(url=meta_find_url,data=body).json()



    message = {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": "Successfully written to snekboop " + str(shards)
    }
    return message
